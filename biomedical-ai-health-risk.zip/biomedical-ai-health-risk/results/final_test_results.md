# Hold-out test results

Dataset: SYNTHETIC (placeholder - replace with real UCI data)
Test rows: 61
GA attempt used: 2  |  Selected features: age, sex, trestbps, thalach, exang, ca

| Model | Accuracy | Precision | Recall | F1 | AUC |
|---|---|---|---|---|---|
| RandomForest - all 13 features | 0.787 | 0.797 | 0.979 | 0.879 | 0.697 |
| RandomForest - GA-selected 6 features | 0.803 | 0.833 | 0.938 | 0.882 | 0.756 |
| Fuzzy system only | 0.721 | 0.804 | 0.854 | 0.828 | 0.515 |
| Hybrid (0.6 ML + 0.4 fuzzy) | 0.803 | 0.833 | 0.938 | 0.882 | 0.731 |

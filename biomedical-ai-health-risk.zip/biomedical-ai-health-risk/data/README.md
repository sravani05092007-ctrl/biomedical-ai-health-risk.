# Data

Place the real dataset here before final submission:

- Download **Heart Disease (Cleveland)** from the UCI Machine Learning Repository.
- Save it as `data/processed.cleveland.data` (original, no header) **or** `data/heart.csv` (with a `target` column).

If neither file exists, `src/data.py` generates a **synthetic placeholder** with the same 13 columns so the pipeline still runs.
Results produced on the placeholder are for testing only. After adding the real file, re-run the commands in the main README and the results files are regenerated.

`resources.csv` is a small curated sample of official portals and major hospitals. Extend it with verified entries for your city.
